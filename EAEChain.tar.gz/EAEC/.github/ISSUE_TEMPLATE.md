Hi there,

please note that this is an issue tracker reserved for bug reports and feature requests.

For general questions please use the gitter channel or the Eaechain stack exchange at https://eaechaineum.stackexchange.com.

#### System information

Geaec version: `geaec version`
OS & Version: Windows/Linux/OSX
Commit hash : (if `develop`)

#### Expected behaviour


#### Actual behaviour


#### Steps to reproduce the behaviour


#### Backtrace

````
[backtrace]
````
