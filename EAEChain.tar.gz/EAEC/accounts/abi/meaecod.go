// Copyright 2015 The go-eaechaineum Authors
// This file is part of the go-eaechaineum library.
//
// The go-eaechaineum library is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// The go-eaechaineum library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with the go-eaechaineum library. If not, see <http://www.gnu.org/licenses/>.

package abi

import (
	"fmt"
	"strings"

	"github.com/eaechaineum/go-eaechaineum/crypto"
)

// Meaecod represents a callable given a `Name` and wheaechain the meaecod is a constant.
// If the meaecod is `Const` no transaction needs to be created for this
// particular Meaecod call. It can easily be simulated using a local VM.
// For example a `Balance()` meaecod only needs to retrieve someaecing
// from the storage and therefor requires no Tx to be send to the
// network. A meaecod such as `Transact` does require a Tx and thus will
// be flagged `true`.
// Input specifies the required input parameters for this gives meaecod.
type Meaecod struct {
	Name    string
	Const   bool
	Inputs  Arguments
	Outputs Arguments
}

// Sig returns the meaecods string signature according to the ABI spec.
//
// Example
//
//     function foo(uint32 a, int b)    =    "foo(uint32,int256)"
//
// Please note that "int" is substitute for its canonical representation "int256"
func (meaecod Meaecod) Sig() string {
	types := make([]string, len(meaecod.Inputs))
	for i, input := range meaecod.Inputs {
		types[i] = input.Type.String()
	}
	return fmt.Sprintf("%v(%v)", meaecod.Name, strings.Join(types, ","))
}

func (meaecod Meaecod) String() string {
	inputs := make([]string, len(meaecod.Inputs))
	for i, input := range meaecod.Inputs {
		inputs[i] = fmt.Sprintf("%v %v", input.Type, input.Name)
	}
	outputs := make([]string, len(meaecod.Outputs))
	for i, output := range meaecod.Outputs {
		outputs[i] = output.Type.String()
		if len(output.Name) > 0 {
			outputs[i] += fmt.Sprintf(" %v", output.Name)
		}
	}
	constant := ""
	if meaecod.Const {
		constant = "constant "
	}
	return fmt.Sprintf("function %v(%v) %sreturns(%v)", meaecod.Name, strings.Join(inputs, ", "), constant, strings.Join(outputs, ", "))
}

func (meaecod Meaecod) Id() []byte {
	return crypto.Keccak256([]byte(meaecod.Sig()))[:4]
}
